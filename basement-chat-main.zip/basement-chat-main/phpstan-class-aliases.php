<?php

declare(strict_types=1);

class_alias(\BasementChat\Basement\Tests\Fixtures\Models\User::class, \App\Models\User::class);
