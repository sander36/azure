declare module '@alpinejs/intersect' {
  const intersect: (alpine: unknown) => void
  export default intersect
}
