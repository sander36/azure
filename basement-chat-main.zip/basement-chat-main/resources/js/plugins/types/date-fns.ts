import type { intlFormat } from 'date-fns'

export type FormatOptions = Parameters<typeof intlFormat>[1]
