enum NotificationStatus {
  Allowed = 'ALLOWED',
  Muted = 'MUTED',
}

export default NotificationStatus
