enum MessageType {
  Document = 'DOCUMENT',
  Text = 'TEXT',
}

export default MessageType
