<input
    {{ $attributes->merge([
        'type' => 'text',
        'class' =>
            'bm-form-input bm-w-full bm-bg-white bm-border bm-border-gray-300 bm-rounded-md bm-text-sm focus:bm-outline-none focus:bm-ring-1 focus:bm-border-sky-300 focus:bm-ring-sky-300',
    ]) }}
/>
