<x-basement::atoms.buttons.header {{ $attributes->merge([
    'data-title' => 'Minimize',
]) }}>
    <x-basement::atoms.icons.fas-minus class="bm-m-auto bm-h-[0.9rem]" />
</x-basement::atoms.buttons.header>
